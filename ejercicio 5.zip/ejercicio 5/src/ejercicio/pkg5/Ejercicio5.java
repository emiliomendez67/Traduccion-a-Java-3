/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg5;

import java.util.Scanner;

/**
 *
 * @author Emilio Maximiliano Méndez Celi
 */
public class Ejercicio5 {

    public static void operaciones(double a, double b) {

        System.out.println("Suma: " + (a + b));
        System.out.println("Resta: " + (a - b));
        System.out.println("Multiplicacion: " + (a * b));

        if (b != 0) {
            System.out.println("Division: " + (a / b));
        } else {
            System.out.println("No se puede dividir para cero.");
        }
    }
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.print("Ingrese el primer numero: ");
        double a = leer.nextDouble();

        System.out.print("Ingrese el segundo numero: ");
        double b = leer.nextDouble();

        operaciones(a, b);
    }
    
}
