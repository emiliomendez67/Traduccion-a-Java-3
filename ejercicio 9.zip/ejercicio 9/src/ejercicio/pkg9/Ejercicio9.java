/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg9;

import java.util.Scanner;

/**
 *
 * @author Emilio Maximiliano Méndez Celi
 */
public class Ejercicio9 {

     public static double calcularPromedio(double n1, double n2, double n3) {

        return (n1 + n2 + n3) / 3;
    }
     
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.print("Nota 1: ");
        double n1 = leer.nextDouble();

        System.out.print("Nota 2: ");
        double n2 = leer.nextDouble();

        System.out.print("Nota 3: ");
        double n3 = leer.nextDouble();

        double promedio = calcularPromedio(n1, n2, n3);

        System.out.println("Promedio: " + promedio);

        if (promedio >= 7) {
            System.out.println("Aprobado.");
        } else {
            System.out.println("Reprobado.");
        }
    }
    
}
