/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Emilio Maximiliano Méndez Celi
 */
public class Ejercicio2 {

    
    public static void numPares(){
    for (int i=2; i <= 100; i+=2){
        System.out.println(i);
    }
        
}
    public static void main(String[] args) {
        numPares();
    }
    
}
