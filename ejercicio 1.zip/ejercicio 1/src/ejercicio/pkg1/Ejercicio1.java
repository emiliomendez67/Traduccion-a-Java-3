/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

/**
 *
 * @author Emilio Maximiliano Méndez Celi
 */
public class Ejercicio1 {

    
    public static void bienvenida() {
        System.out.println("Bienvenido a UTMACH");
        System.out.println("Tecnicas de Programacion");
        System.out.println("Emilio Maximiliano Mendez Celi");
        
    }
    public static void main(String[] args) { 
       bienvenida(); 
    }
    
}
