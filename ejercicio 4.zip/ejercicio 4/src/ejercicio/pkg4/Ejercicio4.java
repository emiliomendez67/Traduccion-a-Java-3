/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg4;

import java.util.Scanner;

/**
 *
 * @author Emilio Maximiliano Méndez Celi
 */
public class Ejercicio4 {

    public static void mostrarDatos(String nombre, int edad) {

        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);

        if (edad >= 18) {
            System.out.println("Es mayor de edad.");
        } else {
            System.out.println("Es menor de edad.");
        }
    }

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.print("Nombre: ");
        String nombre = leer.nextLine();

        System.out.print("Edad: ");
        int edad = leer.nextInt();

        mostrarDatos(nombre, edad);
    }
    
}
