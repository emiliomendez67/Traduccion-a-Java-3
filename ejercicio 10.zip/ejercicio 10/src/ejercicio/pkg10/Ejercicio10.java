/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg10;

import java.util.Scanner;

/**
 *
 * @author Emilio Maximiliano Méndez Celi
 */
public class Ejercicio10 {

    public static int mayor(int a, int b) {

        if (a > b) {
            return a;
        } else {
            return b;
        }
    }
    public static void main(String[] args) {
          Scanner leer = new Scanner(System.in);

        System.out.print("Ingrese el primer número: ");
        int a = leer.nextInt();

        System.out.print("Ingrese el segundo número: ");
        int b = leer.nextInt();

        System.out.println("El mayor es: " + mayor(a, b));
    }
    
}
