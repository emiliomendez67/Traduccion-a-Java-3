/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg11;

import java.util.Scanner;

/**
 *
 * @author Emilio Maximiliano Méndez Celi
 */
public class Ejercicio11 {

     public static boolean esPar(int numero) {

        return numero % 2 == 0;
    }

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.print("Ingrese un número: ");
        int numero = leer.nextInt();

        if (esPar(numero)) {
            System.out.println("El número es par.");
        } else {
            System.out.println("El número es impar.");
        }
    }
    
}
