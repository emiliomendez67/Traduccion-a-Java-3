/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg8;

import java.util.Scanner;

/**
 *
 * @author Emilio Maximiliano Méndez Celi
 */
public class Ejercicio8 {

    public static double calcularArea(double base, double altura) {

        return base * altura;
    }
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.print("Base: ");
        double base = leer.nextDouble();

        System.out.print("Altura: ");
        double altura = leer.nextDouble();

        double area = calcularArea(base, altura);

        System.out.println("Area = " + area);
    }
    
}
